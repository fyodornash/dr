# AUTO GENERATED FILE - DO NOT EDIT

from dash.development.base_component import Component, _explicitize_args


class FullScreen(Component):
    """A FullScreen component.
This component is able to render target elements as full-screen.

Functional component: this component does not need to be wrapped in
`ddk.App`, and will work as intended themed or not.

Keyword arguments:
- children (a list of or a singular dash component, string or number; optional): The element that, when clicked, will activate a fullscreen state
- id (string; optional): The optional id of the component
- className (string; optional): The optional className of the component
- cardRef (a list of or a singular dash component, string or number; optional): A reference to a card to expand
- target_id (string; optional): The id of the DOM element to expand to full screen
- hide_target (boolean; optional): An option to initialize the fullscreen target as hidden
- expanded (boolean; optional): A boolean representing the current expanded state of the target element
- setProps (boolean | number | string | dict | list; optional): Dash-assigned callback that gets fired when the value changes
- style (dict; optional): Overrides the default (inline) styles for the this component."""
    @_explicitize_args
    def __init__(self, children=None, id=Component.UNDEFINED, className=Component.UNDEFINED, cardRef=Component.UNDEFINED, target_id=Component.UNDEFINED, hide_target=Component.UNDEFINED, expanded=Component.UNDEFINED, style=Component.UNDEFINED, **kwargs):
        self._prop_names = ['children', 'id', 'className', 'cardRef', 'target_id', 'hide_target', 'expanded', 'setProps', 'style']
        self._type = 'FullScreen'
        self._namespace = 'dash_design_kit'
        self._valid_wildcard_attributes =            []
        self.available_properties = ['children', 'id', 'className', 'cardRef', 'target_id', 'hide_target', 'expanded', 'setProps', 'style']
        self.available_wildcard_properties =            []

        _explicit_args = kwargs.pop('_explicit_args')
        _locals = locals()
        _locals.update(kwargs)  # For wildcard attrs
        args = {k: _locals[k] for k in _explicit_args if k != 'children'}

        for k in []:
            if k not in args:
                raise TypeError(
                    'Required argument `' + k + '` was not specified.')
        super(FullScreen, self).__init__(children=children, **args)

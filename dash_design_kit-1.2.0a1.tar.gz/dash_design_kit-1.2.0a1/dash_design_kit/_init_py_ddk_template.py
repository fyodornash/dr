import plotly.io as pio
from plotly.graph_objs.layout import Template

def _setup_template(n_colorway_colors=10, n_colorscale_colors=10):
    colorway = ['var(--colorway-{})'.format(i) for i in range(n_colorway_colors)]
    colorscale = ['var(--colorscale-{})'.format(i) for i in range(n_colorscale_colors)]

    ddk_template = Template({
        'layout': {
            'colorscale': {
                'sequential': list(map(list, (zip([x/(len(colorscale)-1) for x in list(range(len(colorscale)))], colorscale))))
            },
            'colorway': colorway,
        }
    })

    pio.templates.default = ddk_template

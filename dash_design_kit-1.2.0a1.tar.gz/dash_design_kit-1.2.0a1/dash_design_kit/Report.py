# AUTO GENERATED FILE - DO NOT EDIT

from dash.development.base_component import Component, _explicitize_args


class Report(Component):
    """A Report component.


Keyword arguments:
- children (boolean | number | string | dict | list; optional)
- style (dict; optional)
- style_page (dict; optional)
- style_page_even (dict; optional)
- style_page_odd (dict; optional)
- display_page_numbers (boolean; optional)
- className (string; optional)
- id (string; optional)
- size (a value equal to: 'letter', 'legal', 'a4'; default 'letter')
- orientation (a value equal to: 'vertical', 'horizontal'; default 'vertical')
- page_number_start_from (number; optional)
- page_margin (dict; optional): page_margin has the following type: dict containing keys 'left', 'right', 'top', 'bottom'.
Those keys have the following types:
  - left (string; optional)
  - right (string; optional)
  - top (string; optional)
  - bottom (string; optional)
- page_margin_even (dict; optional): page_margin_even has the following type: dict containing keys 'left', 'right', 'top', 'bottom'.
Those keys have the following types:
  - left (string; optional)
  - right (string; optional)
  - top (string; optional)
  - bottom (string; optional)
- page_margin_odd (dict; optional): page_margin_odd has the following type: dict containing keys 'left', 'right', 'top', 'bottom'.
Those keys have the following types:
  - left (string; optional)
  - right (string; optional)
  - top (string; optional)
  - bottom (string; optional)"""
    @_explicitize_args
    def __init__(self, children=None, style=Component.UNDEFINED, style_page=Component.UNDEFINED, style_page_even=Component.UNDEFINED, style_page_odd=Component.UNDEFINED, display_page_numbers=Component.UNDEFINED, className=Component.UNDEFINED, id=Component.UNDEFINED, size=Component.UNDEFINED, orientation=Component.UNDEFINED, page_number_start_from=Component.UNDEFINED, page_margin=Component.UNDEFINED, page_margin_even=Component.UNDEFINED, page_margin_odd=Component.UNDEFINED, **kwargs):
        self._prop_names = ['children', 'style', 'style_page', 'style_page_even', 'style_page_odd', 'display_page_numbers', 'className', 'id', 'size', 'orientation', 'page_number_start_from', 'page_margin', 'page_margin_even', 'page_margin_odd']
        self._type = 'Report'
        self._namespace = 'dash_design_kit'
        self._valid_wildcard_attributes =            []
        self.available_properties = ['children', 'style', 'style_page', 'style_page_even', 'style_page_odd', 'display_page_numbers', 'className', 'id', 'size', 'orientation', 'page_number_start_from', 'page_margin', 'page_margin_even', 'page_margin_odd']
        self.available_wildcard_properties =            []

        _explicit_args = kwargs.pop('_explicit_args')
        _locals = locals()
        _locals.update(kwargs)  # For wildcard attrs
        args = {k: _locals[k] for k in _explicit_args if k != 'children'}

        for k in []:
            if k not in args:
                raise TypeError(
                    'Required argument `' + k + '` was not specified.')
        super(Report, self).__init__(children=children, **args)

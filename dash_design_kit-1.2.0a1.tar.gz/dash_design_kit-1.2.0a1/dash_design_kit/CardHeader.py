# AUTO GENERATED FILE - DO NOT EDIT

from dash.development.base_component import Component, _explicitize_args


class CardHeader(Component):
    """A CardHeader component.


Keyword arguments:
- children (a list of or a singular dash component, string or number; optional)
- id (string; optional)
- title (string; optional): string or Dash component; optional
- modal (boolean; optional): Displays an icon that allows the card to be expanded to a modal.
- copy (boolean; optional): Displays an icon that allows the card's innerText to be copied
to the clipboard.
- modal_config (dict; optional): Object that takes 'width' and 'height' arguments to define modal dimensions
Width or height can either be a string or a num N that gets converted to N%. modal_config has the following type: dict containing keys 'width', 'height'.
Those keys have the following types:
  - width (string | number; optional)
  - height (string | number; optional)
- fullscreen (boolean; optional): Displays an icon that allows the card to be expanded to a modal.
- style (dict; optional): Optional additional CSS styles.
- If `width`, `padding`, or `margin` are supplied within `style`,
then this will override the component-level `width`, `padding`, or `margin`.
- className (string; optional)"""
    @_explicitize_args
    def __init__(self, children=None, id=Component.UNDEFINED, title=Component.UNDEFINED, modal=Component.UNDEFINED, copy=Component.UNDEFINED, modal_config=Component.UNDEFINED, fullscreen=Component.UNDEFINED, style=Component.UNDEFINED, className=Component.UNDEFINED, **kwargs):
        self._prop_names = ['children', 'id', 'title', 'modal', 'copy', 'modal_config', 'fullscreen', 'style', 'className']
        self._type = 'CardHeader'
        self._namespace = 'dash_design_kit'
        self._valid_wildcard_attributes =            []
        self.available_properties = ['children', 'id', 'title', 'modal', 'copy', 'modal_config', 'fullscreen', 'style', 'className']
        self.available_wildcard_properties =            []

        _explicit_args = kwargs.pop('_explicit_args')
        _locals = locals()
        _locals.update(kwargs)  # For wildcard attrs
        args = {k: _locals[k] for k in _explicit_args if k != 'children'}

        for k in []:
            if k not in args:
                raise TypeError(
                    'Required argument `' + k + '` was not specified.')
        super(CardHeader, self).__init__(children=children, **args)

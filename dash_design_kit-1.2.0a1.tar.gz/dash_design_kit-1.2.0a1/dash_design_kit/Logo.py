# AUTO GENERATED FILE - DO NOT EDIT

from dash.development.base_component import Component, _explicitize_args


class Logo(Component):
    """A Logo component.
A component to display logos (images) within `ddk.Header` or `ddk.Sidebar`.

Keyword arguments:
- src (string; optional): The image URL. This can be local or remote.
For local images, place your image in the apps
`assets/` folder and pass in a `src` URL like
`/assets/logo.png`.
- alt (string; optional): The alt attribute contains a textual description of the image,
which isn't mandatory but is incredibly useful for accessibility
  - screenreaders read this description out to their users so
they know what the image shows, and it is also displayed on the
page if the image can't be loaded for some reason.
- style (dict; optional): Optional style on the div that wraps the underlying logo `img`
- className (string; optional): className applied to the div that wraps the underlying logo `img`"""
    @_explicitize_args
    def __init__(self, src=Component.UNDEFINED, alt=Component.UNDEFINED, style=Component.UNDEFINED, className=Component.UNDEFINED, **kwargs):
        self._prop_names = ['src', 'alt', 'style', 'className']
        self._type = 'Logo'
        self._namespace = 'dash_design_kit'
        self._valid_wildcard_attributes =            []
        self.available_properties = ['src', 'alt', 'style', 'className']
        self.available_wildcard_properties =            []

        _explicit_args = kwargs.pop('_explicit_args')
        _locals = locals()
        _locals.update(kwargs)  # For wildcard attrs
        args = {k: _locals[k] for k in _explicit_args if k != 'children'}

        for k in []:
            if k not in args:
                raise TypeError(
                    'Required argument `' + k + '` was not specified.')
        super(Logo, self).__init__(**args)

# AUTO GENERATED FILE - DO NOT EDIT

from dash.development.base_component import Component, _explicitize_args


class Header(Component):
    """A Header component.
An app-level header component.

**Example Usage**
```
ddk.Header([
    ddk.Title('FRED Economic Indicators'),
    ddk.Logo(src='/assets/my-logo.png'),
    ddk.Menu([
        ddk.CollapsibleMenu(
            title='Monetary Data',
            children=[
                dcc.Link(
                'Monetary Base',
                href='/monetary-base'
            ),
            dcc.Link(
                'Money Velocity',
                href='/money-velocity'
            ),
            dcc.Link(
                'Reserves',
                href='/reserves'
            ),
            dcc.Link(
                'Borrowings',
                href='/borrowings'
            )
        ]),
        dcc.Link('Conditions', href='/conditions'),
        dcc.Link('Investment', href='/investments'),
        dcc.Link('Other', href='/other'),
    ])
])
```

Keyword arguments:
- children (a list of or a singular dash component, string or number; optional): The contents of the Header.
This is frequently a list containing
a `ddk.Logo`, a `ddk.Title`, and a `ddk.Menu`:
```
[
    ddk.Logo(src='/assets/logo.png'),
    ddk.Title('Header Title'),
    ddk.Menu([
        dcc.Link('Historical', href='/historical'),
        dcc.Link('Forecast', href='/forecast')
    ]),
]
```
but it can also contain arbitrary components
like controls or buttons.
- id (string; optional)
- style (dict; optional): The style object of the outermost div of the Sidebar.
Use this to override the Sidebar's height
(`{'height': '100px'}`) or the background color
(`{'backgroundColor': 'white'}`)"""
    @_explicitize_args
    def __init__(self, children=None, id=Component.UNDEFINED, style=Component.UNDEFINED, **kwargs):
        self._prop_names = ['children', 'id', 'style']
        self._type = 'Header'
        self._namespace = 'dash_design_kit'
        self._valid_wildcard_attributes =            []
        self.available_properties = ['children', 'id', 'style']
        self.available_wildcard_properties =            []

        _explicit_args = kwargs.pop('_explicit_args')
        _locals = locals()
        _locals.update(kwargs)  # For wildcard attrs
        args = {k: _locals[k] for k in _explicit_args if k != 'children'}

        for k in []:
            if k not in args:
                raise TypeError(
                    'Required argument `' + k + '` was not specified.')
        super(Header, self).__init__(children=children, **args)

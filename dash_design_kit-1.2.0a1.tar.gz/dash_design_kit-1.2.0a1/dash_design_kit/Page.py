# AUTO GENERATED FILE - DO NOT EDIT

from dash.development.base_component import Component, _explicitize_args


class Page(Component):
    """A Page component.


Keyword arguments:
- children (boolean | number | string | dict | list; optional)
- style (dict; optional)
- className (string; optional)
- id (string; optional)
- display_page_number (boolean; optional)
- page_margin (dict; optional): page_margin has the following type: dict containing keys 'left', 'right', 'top', 'bottom'.
Those keys have the following types:
  - left (string; optional)
  - right (string; optional)
  - top (string; optional)
  - bottom (string; optional)"""
    @_explicitize_args
    def __init__(self, children=None, style=Component.UNDEFINED, className=Component.UNDEFINED, id=Component.UNDEFINED, display_page_number=Component.UNDEFINED, page_margin=Component.UNDEFINED, **kwargs):
        self._prop_names = ['children', 'style', 'className', 'id', 'display_page_number', 'page_margin']
        self._type = 'Page'
        self._namespace = 'dash_design_kit'
        self._valid_wildcard_attributes =            []
        self.available_properties = ['children', 'style', 'className', 'id', 'display_page_number', 'page_margin']
        self.available_wildcard_properties =            []

        _explicit_args = kwargs.pop('_explicit_args')
        _locals = locals()
        _locals.update(kwargs)  # For wildcard attrs
        args = {k: _locals[k] for k in _explicit_args if k != 'children'}

        for k in []:
            if k not in args:
                raise TypeError(
                    'Required argument `' + k + '` was not specified.')
        super(Page, self).__init__(children=children, **args)
